import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import paymentsRouter from "./routes/payments.js";
import escrowRouter from "./routes/escrow.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// Fail loudly at boot if secrets are missing, instead of failing silently at payment time
const requiredEnv = ["PAYSTACK_SECRET_KEY", "PAYSTACK_PUBLIC_KEY"];
const missing = requiredEnv.filter((key) => !process.env[key]);
if (missing.length) {
  console.warn(
    `⚠️  Missing environment variables: ${missing.join(", ")}. ` +
      `Copy .env.example to .env and fill in your real Paystack keys before accepting live payments.`
  );
}

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
  })
);
app.use(express.json());

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "naijalocal-backend" });
});

app.use("/api/payments", paymentsRouter);
app.use("/api/escrow", escrowRouter);

app.listen(PORT, () => {
  console.log(`NaijaLocal backend running on port ${PORT}`);
});
