import express from "express";
import axios from "axios";

const router = express.Router();

const PAYSTACK_BASE_URL = "https://api.paystack.co";

function paystackClient() {
  // The secret key is read fresh from process.env on every call.
  // It is never hard-coded, logged, or returned to the client.
  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) {
    throw new Error(
      "PAYSTACK_SECRET_KEY is not set. Add it to backend/.env (see .env.example)."
    );
  }
  return axios.create({
    baseURL: PAYSTACK_BASE_URL,
    headers: {
      Authorization: `Bearer ${secretKey}`,
      "Content-Type": "application/json",
    },
  });
}

/**
 * POST /api/payments/initialize
 * body: { email, amountNaira, orderId, productId, buyerId, sellerId }
 * Initializes a Paystack transaction. Amount is converted to kobo server-side
 * so the client can never tamper with the charge amount.
 */
router.post("/initialize", async (req, res) => {
  try {
    const { email, amountNaira, orderId, productId, buyerId, sellerId } = req.body;

    if (!email || !amountNaira || !orderId) {
      return res.status(400).json({
        error: "email, amountNaira, and orderId are required.",
      });
    }

    const client = paystackClient();
    const response = await client.post("/transaction/initialize", {
      email,
      amount: Math.round(Number(amountNaira) * 100), // Paystack expects kobo
      metadata: {
        orderId,
        productId,
        buyerId,
        sellerId,
        custom_fields: [
          { display_name: "Order ID", variable_name: "order_id", value: orderId },
        ],
      },
      callback_url: `${process.env.CLIENT_URL || "http://localhost:5173"}/checkout/callback`,
    });

    return res.json(response.data);
  } catch (err) {
    console.error("Paystack initialize error:", err.response?.data || err.message);
    return res.status(500).json({
      error: "Could not initialize payment.",
      detail: err.response?.data?.message || err.message,
    });
  }
});

/**
 * GET /api/payments/verify/:reference
 * Verifies a transaction with Paystack before releasing funds into escrow.
 * ALWAYS verify server-side — never trust a client-side "success" callback alone.
 */
router.get("/verify/:reference", async (req, res) => {
  try {
    const { reference } = req.params;
    const client = paystackClient();
    const response = await client.get(`/transaction/verify/${encodeURIComponent(reference)}`);

    const { status, amount, currency, paid_at, metadata } = response.data.data;

    if (status !== "success") {
      return res.status(200).json({ verified: false, status });
    }

    // TODO: persist escrow record in Supabase here:
    // - mark order as "funds_held_in_escrow"
    // - store paid_at, amount, reference
    // - start the 45-hour auto-release timer (see routes/escrow.js)

    return res.json({
      verified: true,
      amount: amount / 100,
      currency,
      paidAt: paid_at,
      metadata,
    });
  } catch (err) {
    console.error("Paystack verify error:", err.response?.data || err.message);
    return res.status(500).json({
      error: "Could not verify payment.",
      detail: err.response?.data?.message || err.message,
    });
  }
});

export default router;
