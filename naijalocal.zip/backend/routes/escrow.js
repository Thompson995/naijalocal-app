import express from "express";

const router = express.Router();

// Timing rules (locked-in product spec)
const STANDARD_AUTO_RELEASE_HOURS = 45;
const PERISHABLE_DISPUTE_WINDOW_HOURS = 1;
const STANDARD_DISPUTE_WINDOW_HOURS = 45;

const hoursToMs = (h) => h * 60 * 60 * 1000;

/**
 * These endpoints assume an `orders` table in Supabase with columns such as:
 * id, buyer_id, seller_id, product_id, is_perishable, status,
 * paid_at, delivered_at, confirmed_at, dispute_opened_at, qr_code, auto_release_at
 *
 * This file intentionally keeps business logic framework-agnostic so it can be
 * dropped into a Supabase Edge Function / cron job as-is.
 */

/**
 * Call this right after a payment is verified (see payments.js /verify).
 * Sets the auto-release deadline and the applicable dispute window.
 */
router.post("/start", (req, res) => {
  const { orderId, isPerishable } = req.body;
  if (!orderId) return res.status(400).json({ error: "orderId is required." });

  const now = new Date();
  const autoReleaseAt = new Date(now.getTime() + hoursToMs(STANDARD_AUTO_RELEASE_HOURS));
  const disputeWindowHours = isPerishable
    ? PERISHABLE_DISPUTE_WINDOW_HOURS
    : STANDARD_DISPUTE_WINDOW_HOURS;
  const disputeDeadline = new Date(now.getTime() + hoursToMs(disputeWindowHours));

  // TODO: write these to the orders row in Supabase.
  return res.json({
    orderId,
    status: "funds_held_in_escrow",
    autoReleaseAt: autoReleaseAt.toISOString(),
    disputeDeadline: disputeDeadline.toISOString(),
    disputeWindowHours,
  });
});

/**
 * Buyer scans the seller's QR code on delivery to confirm receipt.
 * This should immediately release escrow funds to the seller.
 */
router.post("/confirm-delivery", (req, res) => {
  const { orderId, qrCode, scannedByBuyerId } = req.body;
  if (!orderId || !qrCode || !scannedByBuyerId) {
    return res.status(400).json({ error: "orderId, qrCode, and scannedByBuyerId are required." });
  }

  // TODO: validate qrCode matches the order's stored code in Supabase,
  // then set status = "released", confirmed_at = now(), release funds via Paystack Transfer.
  return res.json({
    orderId,
    status: "released",
    releasedAt: new Date().toISOString(),
    reason: "buyer_confirmed_via_qr",
  });
});

/**
 * Cron/scheduled job target: run this hourly (e.g. Supabase Edge Function + pg_cron).
 * Auto-releases any order past its 45-hour window with no confirmation and no open dispute,
 * and flags the buyer for review per the blacklist rule.
 */
router.post("/run-auto-release-sweep", (_req, res) => {
  // TODO in Supabase:
  // SELECT * FROM orders
  // WHERE status = 'funds_held_in_escrow'
  //   AND auto_release_at <= now()
  //   AND dispute_opened_at IS NULL;
  // For each: set status = 'released', release_reason = 'auto_release_45h',
  // increment buyer.missed_confirmations, and flag for blacklist review if repeated.
  return res.json({
    message:
      "Auto-release sweep endpoint — wire this to a scheduled job (e.g. Supabase pg_cron calling this route hourly).",
  });
});

/**
 * Buyer or seller opens a dispute within the applicable window
 * (1 hour for perishables, 45 hours for standard items).
 */
router.post("/dispute", (req, res) => {
  const { orderId, raisedBy, reason } = req.body;
  if (!orderId || !raisedBy || !reason) {
    return res.status(400).json({ error: "orderId, raisedBy, and reason are required." });
  }

  // TODO: check dispute_deadline hasn't passed before allowing this in Supabase.
  return res.json({
    orderId,
    status: "disputed",
    disputeOpenedAt: new Date().toISOString(),
    raisedBy,
    reason,
  });
});

export default router;
