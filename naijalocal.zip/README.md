# NaijaLocal

A hyperlocal, trust-first peer-to-peer marketplace for Akwa Ibom communities.

## ⚠️ Read this first — API key security

A Paystack **secret key** was shared in plain chat before this project was
generated. Treat that key as burned:

1. Log in to the [Paystack Dashboard](https://dashboard.paystack.com/#/settings/developer).
2. Regenerate/roll both the secret and public keys.
3. Put the **new** secret key only in `backend/.env` (never `frontend/.env`, never committed).
4. Put the **new** public key in `frontend/.env` — the public key is safe to
   expose in frontend code, the secret key never is.

Both `.env` files are already git-ignored in this project. Only `.env.example`
files (with placeholder values) are meant to be committed.

## Project structure

```
naijalocal/
├── backend/          Express API — Paystack initialize/verify, escrow logic
│   ├── routes/
│   │   ├── payments.js   Payment initialize/verify (Paystack)
│   │   └── escrow.js     45h auto-release, dispute windows, QR confirmation
│   ├── server.js
│   └── .env.example
└── frontend/         React + Vite + Tailwind
    ├── src/
    │   ├── components/
    │   │   ├── Navbar.jsx, Hero.jsx, Footer.jsx
    │   │   ├── Marketplace.jsx, ProductCard.jsx, TrustBadge.jsx
    │   │   ├── UploadProduct.jsx      "Sell" — list a product
    │   │   ├── ChatSpace.jsx          In-app chat + AI Negotiator
    │   │   └── dashboard/Charts.jsx   Trust Ledger charts (recharts)
    │   ├── data/mockData.js           Swap for live Supabase queries
    │   └── App.jsx
    └── .env.example
```

## Local setup

```bash
# Backend
cd backend
cp .env.example .env      # then paste your ROTATED Paystack keys
npm install
npm run dev                # http://localhost:4000

# Frontend (new terminal)
cd frontend
cp .env.example .env      # paste your PUBLIC key + Supabase project details
npm install
npm run dev                # http://localhost:5173
```

## Pushing to GitHub

```bash
cd naijalocal
git init
git add .
git status                 # confirm no .env file is listed — only .env.example
git commit -m "Initial NaijaLocal scaffold"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

If `git status` ever shows a `.env` file staged, stop and run
`git rm --cached backend/.env` (or `frontend/.env`) before committing.

## What's implemented vs. stubbed

**Implemented (working UI/logic):**
- Marketplace with seller storefronts, product filtering, search
- Trust badge system (Verified / Trusted Seller / Trusted Buyer / Red Flag / New Seller)
- Trust Ledger charts: weekly trade volume, badge distribution, escrow status
- Product upload form (Sell tab)
- In-app chat with threads, AI Negotiator toggle, online/active status
- Paystack `initialize` and `verify` endpoints, reading keys from `process.env` only
- Escrow route skeleton: 45h auto-release, 1h/45h dispute windows, QR delivery confirmation

**Stubbed — marked with `// TODO` — because they need your live Supabase project:**
- Persisting orders/escrow state to a database
- Actually validating QR codes against stored order data
- Scheduling the hourly auto-release sweep (Supabase `pg_cron` + Edge Function is the
  natural fit)
- Real product/image storage (currently mock data in `src/data/mockData.js`)
- Wiring the AI Negotiator to a real model (Gemini/Groq/OpenRouter) instead of the
  placeholder response in the chat

## Design notes

Brand: forest green `#0D3B2E`, gold `#C9A227`, cream `#F7F1E4`, Fraunces (headings) /
Manrope (body) — matches your locked pitch-deck branding. The gold "handshake-knot"
divider and subtle Adire-inspired watermark echo the logo without repeating the
national-chain, generic-marketplace look.
