import { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import Marketplace from "./components/Marketplace.jsx";
import Charts from "./components/dashboard/Charts.jsx";
import UploadProduct from "./components/UploadProduct.jsx";
import ChatSpace from "./components/ChatSpace.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  const [activeProduct, setActiveProduct] = useState(null);

  const handleOpenChat = (product) => {
    setActiveProduct(product);
    document.getElementById("chat")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      <Hero />
      <Marketplace onOpenChat={handleOpenChat} />
      <Charts />
      <UploadProduct />
      <ChatSpace activeProduct={activeProduct} />
      <Footer />
    </div>
  );
}
