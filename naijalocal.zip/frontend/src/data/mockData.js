// Sample data to make the UI feel real out of the box.
// Replace with live Supabase queries once your tables are wired up.

export const sellers = [
  {
    id: "s1",
    name: "Mama Edet's Kitchen",
    town: "Uyo",
    badge: "Trusted Seller",
    rating: 4.9,
    completedOrders: 214,
    online: true,
    avatarInitials: "ME",
  },
  {
    id: "s2",
    name: "Ekpo Fabrics & Adire",
    town: "Ikot Ekpene",
    badge: "Verified",
    rating: 4.8,
    completedOrders: 132,
    online: true,
    avatarInitials: "EF",
  },
  {
    id: "s3",
    name: "Udo Electronics Hub",
    town: "Eket",
    badge: "New Seller",
    rating: 4.2,
    completedOrders: 9,
    online: false,
    avatarInitials: "UE",
  },
  {
    id: "s4",
    name: "Iniobong Farm Produce",
    town: "Abak",
    badge: "Red Flag",
    rating: 3.1,
    completedOrders: 47,
    online: false,
    avatarInitials: "IF",
  },
];

export const products = [
  {
    id: "p1",
    title: "Fresh Ugba (Oil Bean) — 2kg basket",
    price: 6500,
    sellerId: "s1",
    category: "Food",
    perishable: true,
    image: "food",
  },
  {
    id: "p2",
    title: "Hand-dyed Adire Wrapper, 6 yards",
    price: 24000,
    sellerId: "s2",
    category: "Fashion",
    perishable: false,
    image: "fabric",
  },
  {
    id: "p3",
    title: "Refurbished 32\" LED TV",
    price: 58000,
    sellerId: "s3",
    category: "Electronics",
    perishable: false,
    image: "electronics",
  },
  {
    id: "p4",
    title: "Ripe Plantain Bunch, farm-fresh",
    price: 3200,
    sellerId: "s4",
    category: "Food",
    perishable: true,
    image: "food",
  },
  {
    id: "p5",
    title: "Beaded Coral Set (Bridal)",
    price: 45000,
    sellerId: "s2",
    category: "Fashion",
    perishable: false,
    image: "fabric",
  },
  {
    id: "p6",
    title: "5kg Bag of Local Rice",
    price: 9800,
    sellerId: "s1",
    category: "Food",
    perishable: false,
    image: "food",
  },
];

// Chart section data
export const weeklyTradeVolume = [
  { day: "Mon", naira: 182000 },
  { day: "Tue", naira: 241000 },
  { day: "Wed", naira: 198000 },
  { day: "Thu", naira: 305000 },
  { day: "Fri", naira: 412000 },
  { day: "Sat", naira: 530000 },
  { day: "Sun", naira: 387000 },
];

export const badgeDistribution = [
  { name: "Verified", value: 38 },
  { name: "Trusted Seller", value: 29 },
  { name: "Trusted Buyer", value: 21 },
  { name: "New Seller", value: 9 },
  { name: "Red Flag", value: 3 },
];

export const escrowStatus = [
  { name: "In Escrow", value: 47 },
  { name: "Released (Confirmed)", value: 118 },
  { name: "Auto-Released (45h)", value: 12 },
  { name: "Disputed", value: 4 },
];

export const chatThreads = [
  {
    id: "c1",
    sellerId: "s1",
    productTitle: "Fresh Ugba (Oil Bean) — 2kg basket",
    lastMessage: "I can deliver by 5pm today, is that okay?",
    unread: 2,
    messages: [
      { from: "buyer", text: "Good afternoon, is the ugba still fresh from today?", time: "10:02 AM" },
      { from: "seller", text: "Yes o, picked this morning. Very fresh.", time: "10:05 AM" },
      { from: "ai", text: "Negotiator: Seller's usual price for this size is ₦7,000. Want me to propose ₦6,000?", time: "10:06 AM" },
      { from: "buyer", text: "Yes please try ₦6,000", time: "10:06 AM" },
      { from: "seller", text: "I can do ₦6,500 as my last price.", time: "10:09 AM" },
      { from: "seller", text: "I can deliver by 5pm today, is that okay?", time: "10:10 AM" },
    ],
  },
  {
    id: "c2",
    sellerId: "s2",
    productTitle: "Hand-dyed Adire Wrapper, 6 yards",
    lastMessage: "Bonjour, oui c'est disponible en bleu indigo.",
    unread: 0,
    messages: [
      { from: "buyer", text: "Is this available in indigo blue?", time: "Yesterday" },
      { from: "seller", text: "Bonjour, oui c'est disponible en bleu indigo.", time: "Yesterday" },
    ],
  },
];
