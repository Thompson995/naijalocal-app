import { CircleDot } from "lucide-react";
import TrustBadge from "./TrustBadge.jsx";
import { sellers } from "../data/mockData.js";

export default function Hero() {
  const onlineCount = sellers.filter((s) => s.online).length;

  return (
    <section id="top" className="relative bg-forest overflow-hidden">
      <div className="absolute inset-0 adire-watermark opacity-40" aria-hidden="true" />
      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28 grid lg:grid-cols-[1.15fr_0.85fr] gap-12 items-center">
        <div>
          <span className="inline-flex items-center gap-2 text-gold text-xs font-bold tracking-[0.16em] uppercase mb-5">
            <CircleDot size={13} className="text-goldLight" />
            Built for Akwa Ibom, by neighbors
          </span>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.4rem] leading-[1.08] text-cream font-semibold tracking-tight">
            Trade with people who actually
            <span className="italic text-gold"> live near you.</span>
          </h1>
          <p className="mt-5 text-cream/75 text-base sm:text-lg max-w-xl leading-relaxed">
            No chain stores. No strangers from three states away. Just verified
            buyers and sellers in your own community — every transaction held
            safely in escrow until you confirm delivery.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <a
              href="#marketplace"
              className="text-center bg-gold hover:bg-goldLight text-forestDeep font-semibold px-6 py-3.5 rounded-full transition-colors"
            >
              Browse the Marketplace
            </a>
            <a
              href="#sell"
              className="text-center border border-cream/25 hover:border-gold/60 text-cream font-semibold px-6 py-3.5 rounded-full transition-colors"
            >
              List Something to Sell
            </a>
          </div>

          <div className="mt-10 flex items-center gap-6 text-cream/70 text-sm">
            <div>
              <span className="text-gold font-display text-2xl font-semibold">{onlineCount}</span>{" "}
              sellers active right now
            </div>
            <div className="w-px h-8 bg-cream/15" />
            <div>
              <span className="text-gold font-display text-2xl font-semibold">45h</span> max
              escrow hold, always
            </div>
          </div>
        </div>

        {/* Live trust-ledger snapshot card — the hero's thesis made concrete */}
        <div className="bg-cream rounded-xl2 p-6 shadow-2xl shadow-black/30 border border-gold/20">
          <p className="text-xs font-bold uppercase tracking-widest text-forest/60 mb-4">
            Live on NaijaLocal
          </p>
          <ul className="space-y-3">
            {sellers.map((s) => (
              <li
                key={s.id}
                className="flex items-center justify-between gap-3 py-2 border-b border-forest/8 last:border-0"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="relative w-9 h-9 shrink-0 rounded-full bg-forest text-cream grid place-items-center text-xs font-bold">
                    {s.avatarInitials}
                    {s.online && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-cream" />
                    )}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-forestDeep truncate">{s.name}</p>
                    <p className="text-xs text-forestDeep/50">{s.town}</p>
                  </div>
                </div>
                <TrustBadge tier={s.badge} />
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="knot-divider">
        <svg width="72" height="24" viewBox="0 0 72 24" aria-hidden="true">
          <path
            d="M8 12c6-9 12-11 18-6s6 15 0 21-16 3-24-6M64 12c-6-9-12-11-18-6s-6 15 0 21 16 3 24-6"
            fill="none"
            stroke="#C9A227"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </div>
    </section>
  );
}
