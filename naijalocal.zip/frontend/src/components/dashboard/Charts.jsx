import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import { weeklyTradeVolume, badgeDistribution, escrowStatus } from "../../data/mockData.js";

const GOLD = "#C9A227";
const FOREST = "#0D3B2E";
const GOLD_LIGHT = "#E4C766";
const RED = "#B23A2E";
const CREAM_DARK = "#DCCFA6";

const PIE_COLORS = [FOREST, GOLD, GOLD_LIGHT, CREAM_DARK, RED];

function ChartCard({ title, subtitle, children }) {
  return (
    <div className="bg-white rounded-xl2 border border-forest/8 p-5 sm:p-6">
      <p className="text-xs font-bold uppercase tracking-widest text-gold mb-1">{subtitle}</p>
      <h3 className="font-display text-lg font-semibold text-forestDeep mb-4">{title}</h3>
      {children}
    </div>
  );
}

export default function Charts() {
  return (
    <section id="charts" className="bg-forest/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-20">
        <div className="mb-10">
          <p className="text-xs font-bold uppercase tracking-widest text-gold mb-2">
            Trust Ledger
          </p>
          <h2 className="font-display text-3xl font-semibold text-forestDeep">
            The numbers behind the trust
          </h2>
          <p className="text-forestDeep/60 mt-2 max-w-2xl">
            Every trade, badge, and escrow release across the community — updated live.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <ChartCard title="Weekly Trade Volume (₦)" subtitle="This Week">
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={weeklyTradeVolume}>
                  <defs>
                    <linearGradient id="volumeFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={GOLD} stopOpacity={0.45} />
                      <stop offset="100%" stopColor={GOLD} stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#0D3B2E" strokeOpacity={0.08} />
                  <XAxis dataKey="day" tick={{ fill: "#0D3B2E", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis
                    tick={{ fill: "#0D3B2E", fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `₦${v / 1000}k`}
                  />
                  <Tooltip
                    formatter={(value) => [`₦${value.toLocaleString("en-NG")}`, "Volume"]}
                    contentStyle={{ borderRadius: 10, border: "1px solid rgba(13,59,46,0.12)" }}
                  />
                  <Area type="monotone" dataKey="naira" stroke={GOLD} strokeWidth={2.5} fill="url(#volumeFill)" />
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <ChartCard title="Badge Distribution" subtitle="Community Trust">
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={badgeDistribution}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {badgeDistribution.map((entry, i) => (
                    <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [`${value}%`, name]} />
              </PieChart>
            </ResponsiveContainer>
            <ul className="grid grid-cols-2 gap-x-3 gap-y-1.5 mt-2">
              {badgeDistribution.map((entry, i) => (
                <li key={entry.name} className="flex items-center gap-1.5 text-xs text-forestDeep/70">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }}
                  />
                  {entry.name}
                </li>
              ))}
            </ul>
          </ChartCard>

          <div className="lg:col-span-3">
            <ChartCard title="Escrow Status Across All Orders" subtitle="Paystack Escrow">
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={escrowStatus} layout="vertical" margin={{ left: 24 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#0D3B2E" strokeOpacity={0.08} horizontal={false} />
                  <XAxis type="number" tick={{ fill: "#0D3B2E", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={170}
                    tick={{ fill: "#0D3B2E", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid rgba(13,59,46,0.12)" }} />
                  <Bar dataKey="value" fill={FOREST} radius={[0, 6, 6, 0]} barSize={22} />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </div>
      </div>
    </section>
  );
}
