import { ShieldCheck, Award, HeartHandshake, Flag, Sprout } from "lucide-react";

const BADGE_CONFIG = {
  Verified: {
    icon: ShieldCheck,
    classes: "bg-forest text-cream",
  },
  "Trusted Seller": {
    icon: Award,
    classes: "bg-gold text-forestDeep",
  },
  "Trusted Buyer": {
    icon: HeartHandshake,
    classes: "bg-goldLight text-forestDeep",
  },
  "New Seller": {
    icon: Sprout,
    classes: "bg-cream text-forest border border-forest/30",
  },
  "Red Flag": {
    icon: Flag,
    classes: "bg-flagRed text-cream",
  },
};

export default function TrustBadge({ tier, size = "sm" }) {
  const config = BADGE_CONFIG[tier] || BADGE_CONFIG["New Seller"];
  const Icon = config.icon;
  const sizeClasses = size === "lg" ? "text-xs px-3 py-1" : "";

  return (
    <span className={`badge ${config.classes} ${sizeClasses}`}>
      <Icon size={12} strokeWidth={2.5} />
      {tier}
    </span>
  );
}
