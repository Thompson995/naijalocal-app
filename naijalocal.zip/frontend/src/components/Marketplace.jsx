import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import ProductCard from "./ProductCard.jsx";
import TrustBadge from "./TrustBadge.jsx";
import { products, sellers } from "../data/mockData.js";

const CATEGORIES = ["All", "Food", "Fashion", "Electronics"];

export default function Marketplace({ onOpenChat }) {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [activeSeller, setActiveSeller] = useState(null);

  const sellerById = useMemo(() => Object.fromEntries(sellers.map((s) => [s.id, s])), []);

  const filtered = products.filter((p) => {
    const matchesCategory = category === "All" || p.category === category;
    const matchesQuery = p.title.toLowerCase().includes(query.toLowerCase());
    const matchesSeller = !activeSeller || p.sellerId === activeSeller;
    return matchesCategory && matchesQuery && matchesSeller;
  });

  return (
    <section id="marketplace" className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-20">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-gold mb-2">
            The Marketplace
          </p>
          <h2 className="font-display text-3xl font-semibold text-forestDeep">
            Real sellers, real stalls, real streets
          </h2>
        </div>

        <div className="relative w-full sm:w-72">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-forest/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full pl-10 pr-4 py-2.5 rounded-full border border-forest/15 bg-white text-sm focus:border-gold outline-none"
          />
        </div>
      </div>

      {/* Seller storefronts strip — "test sellers" showcase */}
      <div className="flex gap-3 overflow-x-auto pb-4 mb-6 -mx-1 px-1">
        <button
          onClick={() => setActiveSeller(null)}
          className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold border transition-colors ${
            !activeSeller
              ? "bg-forest text-cream border-forest"
              : "bg-white text-forestDeep border-forest/15 hover:border-forest/40"
          }`}
        >
          All Sellers
        </button>
        {sellers.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSeller(s.id === activeSeller ? null : s.id)}
            className={`shrink-0 flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full text-sm font-semibold border transition-colors ${
              activeSeller === s.id
                ? "bg-forest text-cream border-forest"
                : "bg-white text-forestDeep border-forest/15 hover:border-forest/40"
            }`}
          >
            <span className="relative w-7 h-7 rounded-full bg-gold/90 text-forestDeep grid place-items-center text-[11px] font-bold">
              {s.avatarInitials}
              {s.online && (
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-white" />
              )}
            </span>
            {s.name}
          </button>
        ))}
      </div>

      {/* Category filter */}
      <div className="flex gap-2 mb-8">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide transition-colors ${
              category === c
                ? "bg-gold text-forestDeep"
                : "bg-forest/5 text-forestDeep/60 hover:bg-forest/10"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-forest/20 rounded-xl2">
          <p className="text-forestDeep/60 font-medium">
            Nothing matches yet. Try a different search or category.
          </p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              seller={sellerById[p.sellerId]}
              onOpenChat={onOpenChat}
            />
          ))}
        </div>
      )}

      {activeSeller && (
        <div className="mt-8 flex items-center gap-3 text-sm text-forestDeep/70">
          <span>Viewing storefront:</span>
          <TrustBadge tier={sellerById[activeSeller].badge} />
        </div>
      )}
    </section>
  );
}
