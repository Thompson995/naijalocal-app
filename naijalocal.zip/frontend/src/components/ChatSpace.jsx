import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, Circle } from "lucide-react";
import { chatThreads, sellers } from "../data/mockData.js";

function OnlineDot({ online }) {
  return (
    <Circle
      size={9}
      className={online ? "text-emerald-400 fill-emerald-400" : "text-forestDeep/25 fill-forestDeep/25"}
    />
  );
}

function MessageBubble({ msg }) {
  if (msg.from === "ai") {
    return (
      <div className="flex items-start gap-2 max-w-[85%]">
        <span className="w-6 h-6 rounded-full bg-gold/20 grid place-items-center shrink-0 mt-0.5">
          <Sparkles size={12} className="text-gold" />
        </span>
        <div className="bg-gold/10 border border-gold/30 rounded-xl2 rounded-tl-sm px-3.5 py-2.5">
          <p className="text-xs font-bold text-forestDeep/60 mb-0.5">AI Negotiator</p>
          <p className="text-sm text-forestDeep">{msg.text}</p>
        </div>
      </div>
    );
  }

  const isBuyer = msg.from === "buyer";
  return (
    <div className={`flex ${isBuyer ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[75%] px-3.5 py-2.5 rounded-xl2 text-sm ${
          isBuyer
            ? "bg-forest text-cream rounded-tr-sm"
            : "bg-forest/6 text-forestDeep rounded-tl-sm"
        }`}
      >
        {msg.text}
        <p className={`text-[10px] mt-1 ${isBuyer ? "text-cream/50" : "text-forestDeep/40"}`}>
          {msg.time}
        </p>
      </div>
    </div>
  );
}

export default function ChatSpace({ activeProduct }) {
  const [activeThreadId, setActiveThreadId] = useState(chatThreads[0].id);
  const [threads, setThreads] = useState(chatThreads);
  const [draft, setDraft] = useState("");
  const [aiEnabled, setAiEnabled] = useState(true);
  const scrollRef = useRef(null);

  const activeThread = threads.find((t) => t.id === activeThreadId);
  const activeSeller = sellers.find((s) => s.id === activeThread?.sellerId);

  useEffect(() => {
    if (activeProduct) {
      const match = threads.find((t) => t.sellerId === activeProduct.sellerId);
      if (match) setActiveThreadId(match.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeProduct]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activeThread?.messages.length, activeThreadId]);

  const sendMessage = () => {
    if (!draft.trim()) return;
    setThreads((prev) =>
      prev.map((t) =>
        t.id === activeThreadId
          ? {
              ...t,
              lastMessage: draft,
              messages: [
                ...t.messages,
                { from: "buyer", text: draft, time: "Now" },
                ...(aiEnabled
                  ? [
                      {
                        from: "ai",
                        text: "Negotiator: Noted. I'll flag this to the seller and suggest a fair counter if needed.",
                        time: "Now",
                      },
                    ]
                  : []),
              ],
            }
          : t
      )
    );
    setDraft("");
  };

  return (
    <section id="chat" className="bg-forest/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-20">
        <div className="mb-8">
          <p className="text-xs font-bold uppercase tracking-widest text-gold mb-2">
            In-App Chat
          </p>
          <h2 className="font-display text-3xl font-semibold text-forestDeep">
            Everything stays inside NaijaLocal
          </h2>
          <p className="text-forestDeep/60 mt-2 max-w-xl">
            No WhatsApp handoff. Negotiate, ask questions, and confirm delivery
            details in one native chat space — with an AI Negotiator on standby.
          </p>
        </div>

        <div className="bg-white rounded-xl2 border border-forest/8 overflow-hidden grid md:grid-cols-[280px_1fr] h-[560px]">
          {/* Thread list */}
          <aside className="border-r border-forest/8 overflow-y-auto">
            {threads.map((t) => {
              const seller = sellers.find((s) => s.id === t.sellerId);
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveThreadId(t.id)}
                  className={`w-full text-left px-4 py-3.5 flex items-start gap-3 border-b border-forest/6 transition-colors ${
                    activeThreadId === t.id ? "bg-forest/6" : "hover:bg-forest/3"
                  }`}
                >
                  <span className="relative w-9 h-9 shrink-0 rounded-full bg-forest text-cream grid place-items-center text-xs font-bold">
                    {seller?.avatarInitials}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="text-sm font-semibold text-forestDeep truncate">
                        {seller?.name}
                      </span>
                      <OnlineDot online={seller?.online} />
                    </span>
                    <span className="block text-xs text-forestDeep/50 truncate">
                      {t.productTitle}
                    </span>
                    <span className="block text-xs text-forestDeep/40 truncate mt-0.5">
                      {t.lastMessage}
                    </span>
                  </span>
                  {t.unread > 0 && (
                    <span className="w-5 h-5 shrink-0 rounded-full bg-gold text-forestDeep text-[10px] font-bold grid place-items-center">
                      {t.unread}
                    </span>
                  )}
                </button>
              );
            })}
          </aside>

          {/* Active thread */}
          <div className="flex flex-col min-w-0">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-forest/8">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="relative w-9 h-9 shrink-0 rounded-full bg-forest text-cream grid place-items-center text-xs font-bold">
                  {activeSeller?.avatarInitials}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-forestDeep truncate">
                    {activeSeller?.name}
                  </p>
                  <p className="text-xs text-forestDeep/50 flex items-center gap-1.5">
                    <OnlineDot online={activeSeller?.online} />
                    {activeSeller?.online ? "Active now" : "Offline"}
                  </p>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs font-semibold text-forestDeep/70 shrink-0">
                <Sparkles size={13} className="text-gold" />
                AI Negotiator
                <input
                  type="checkbox"
                  checked={aiEnabled}
                  onChange={(e) => setAiEnabled(e.target.checked)}
                  className="w-3.5 h-3.5 accent-gold"
                />
              </label>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
              {activeThread?.messages.map((msg, i) => (
                <MessageBubble key={i} msg={msg} />
              ))}
            </div>

            <div className="flex items-center gap-2 px-4 py-3.5 border-t border-forest/8">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                placeholder="Type a message..."
                className="flex-1 rounded-full border border-forest/15 px-4 py-2.5 text-sm focus:border-gold outline-none"
              />
              <button
                onClick={sendMessage}
                className="w-10 h-10 shrink-0 rounded-full bg-forest hover:bg-forestDeep text-cream grid place-items-center transition-colors"
                aria-label="Send message"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
