export default function Footer() {
  return (
    <footer className="relative bg-forestDeep overflow-hidden">
      <div className="absolute inset-0 adire-watermark opacity-20" aria-hidden="true" />
      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 py-12 grid sm:grid-cols-3 gap-8">
        <div>
          <p className="font-display text-xl font-semibold text-cream">NaijaLocal</p>
          <p className="text-cream/50 text-sm mt-2 max-w-xs">
            A hyperlocal, trust-first marketplace for Akwa Ibom communities.
            Real neighbors. Escrow-protected trades.
          </p>
        </div>
        <div>
          <p className="text-gold text-xs font-bold uppercase tracking-widest mb-3">Trust & Safety</p>
          <ul className="space-y-2 text-sm text-cream/60">
            <li>How escrow works</li>
            <li>Badge system explained</li>
            <li>Report a Red Flag seller</li>
          </ul>
        </div>
        <div>
          <p className="text-gold text-xs font-bold uppercase tracking-widest mb-3">Company</p>
          <ul className="space-y-2 text-sm text-cream/60">
            <li>About NaijaLocal</li>
            <li>Contact support</li>
            <li>Community guidelines</li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-cream/10 py-5 text-center text-xs text-cream/40">
        © {new Date().getFullYear()} NaijaLocal. Built for Akwa Ibom, by neighbors.
      </div>
    </footer>
  );
}
