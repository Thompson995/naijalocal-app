import { useState } from "react";
import { UploadCloud, CheckCircle2, ImagePlus } from "lucide-react";

const INITIAL_FORM = {
  title: "",
  category: "Food",
  price: "",
  perishable: false,
  description: "",
  deliveryMethod: "Self-pickup",
};

export default function UploadProduct() {
  const [form, setForm] = useState(INITIAL_FORM);
  const [imageName, setImageName] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const update = (key) => (e) => {
    const value = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: send `form` + image file to Supabase (insert into `products`,
    // upload image to Supabase Storage) instead of this local mock.
    console.log("New product submitted:", form, imageName);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm(INITIAL_FORM);
      setImageName("");
    }, 2500);
  };

  return (
    <section id="sell" className="max-w-4xl mx-auto px-5 sm:px-8 py-16 sm:py-20">
      <div className="mb-8">
        <p className="text-xs font-bold uppercase tracking-widest text-gold mb-2">List an Item</p>
        <h2 className="font-display text-3xl font-semibold text-forestDeep">
          Put your product in front of your neighbors
        </h2>
        <p className="text-forestDeep/60 mt-2 max-w-xl">
          Fill this out honestly — your Trust badge is built from how accurately
          your listings match what buyers receive.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-xl2 border border-forest/8 p-6 sm:p-8 grid sm:grid-cols-2 gap-6"
      >
        <label className="sm:col-span-2 flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Product title
          <input
            required
            value={form.title}
            onChange={update("title")}
            placeholder="e.g. Fresh Ugba (Oil Bean) — 2kg basket"
            className="rounded-lg border border-forest/15 px-4 py-2.5 text-sm font-normal focus:border-gold outline-none"
          />
        </label>

        <label className="flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Category
          <select
            value={form.category}
            onChange={update("category")}
            className="rounded-lg border border-forest/15 px-4 py-2.5 text-sm font-normal bg-white focus:border-gold outline-none"
          >
            <option>Food</option>
            <option>Fashion</option>
            <option>Electronics</option>
            <option>Home & Living</option>
            <option>Services</option>
          </select>
        </label>

        <label className="flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Price (₦)
          <input
            required
            type="number"
            min="0"
            value={form.price}
            onChange={update("price")}
            placeholder="6500"
            className="rounded-lg border border-forest/15 px-4 py-2.5 text-sm font-normal focus:border-gold outline-none"
          />
        </label>

        <label className="flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Delivery method
          <select
            value={form.deliveryMethod}
            onChange={update("deliveryMethod")}
            className="rounded-lg border border-forest/15 px-4 py-2.5 text-sm font-normal bg-white focus:border-gold outline-none"
          >
            <option>Self-pickup</option>
            <option>Seller delivers personally</option>
            <option>Seller pays a rider</option>
          </select>
        </label>

        <label className="flex items-center gap-2.5 text-sm font-semibold text-forestDeep mt-1">
          <input
            type="checkbox"
            checked={form.perishable}
            onChange={update("perishable")}
            className="w-4 h-4 accent-gold"
          />
          This item is perishable (1-hour dispute window applies)
        </label>

        <label className="sm:col-span-2 flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Description
          <textarea
            value={form.description}
            onChange={update("description")}
            rows={4}
            placeholder="Describe condition, quantity, and anything a buyer should know..."
            className="rounded-lg border border-forest/15 px-4 py-2.5 text-sm font-normal focus:border-gold outline-none resize-none"
          />
        </label>

        <label className="sm:col-span-2 flex flex-col gap-2 text-sm font-semibold text-forestDeep">
          Product photo
          <div className="flex items-center gap-4 border border-dashed border-forest/25 rounded-lg px-4 py-6 cursor-pointer hover:border-gold transition-colors">
            <ImagePlus size={22} className="text-forest/50" />
            <span className="text-sm font-normal text-forestDeep/60">
              {imageName || "Click to upload a clear photo (JPG or PNG)"}
            </span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => setImageName(e.target.files?.[0]?.name || "")}
            />
          </div>
        </label>

        <button
          type="submit"
          className="sm:col-span-2 flex items-center justify-center gap-2 bg-forest hover:bg-forestDeep text-cream font-semibold py-3.5 rounded-full transition-colors"
        >
          {submitted ? (
            <>
              <CheckCircle2 size={18} /> Listed successfully
            </>
          ) : (
            <>
              <UploadCloud size={18} /> List This Item
            </>
          )}
        </button>
      </form>
    </section>
  );
}
