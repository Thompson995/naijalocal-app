import { useState } from "react";
import { Menu, X, MessageCircle, UploadCloud, BarChart3, Store } from "lucide-react";

const NAV_LINKS = [
  { label: "Marketplace", href: "#marketplace", icon: Store },
  { label: "Sell", href: "#sell", icon: UploadCloud },
  { label: "Trust Ledger", href: "#charts", icon: BarChart3 },
  { label: "Chat", href: "#chat", icon: MessageCircle },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-forest/95 backdrop-blur border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between h-16">
        <a href="#top" className="flex items-center gap-2.5 group">
          <span className="relative w-9 h-9 rounded-md bg-forestDeep grid place-items-center overflow-hidden">
            <svg viewBox="0 0 40 40" className="w-6 h-6">
              <defs>
                <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#E4C766" />
                  <stop offset="100%" stopColor="#9C7A16" />
                </linearGradient>
              </defs>
              <circle cx="20" cy="20" r="17" fill="none" stroke="url(#goldGrad)" strokeWidth="2.5" />
              <path
                d="M12 20c2-3 4-4 6-2s2 5 0 7-6 1-8-2M28 20c-2-3-4-4-6-2s-2 5 0 7 6 1 8-2"
                fill="none"
                stroke="url(#goldGrad)"
                strokeWidth="2.4"
                strokeLinecap="round"
              />
            </svg>
          </span>
          <span className="font-display font-semibold text-lg text-cream tracking-tight">
            NaijaLocal
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map(({ label, href, icon: Icon }) => (
            <a
              key={label}
              href={href}
              className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-cream/85 hover:text-gold transition-colors rounded-md"
            >
              <Icon size={15} />
              {label}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <a
            href="#chat"
            className="text-sm font-semibold text-cream/90 hover:text-gold transition-colors"
          >
            Sign In
          </a>
          <a
            href="#sell"
            className="text-sm font-semibold bg-gold hover:bg-goldLight text-forestDeep px-4 py-2 rounded-full transition-colors"
          >
            Start Selling
          </a>
        </div>

        <button
          className="md:hidden text-cream"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-forestDeep border-t border-gold/20 px-5 py-4 flex flex-col gap-1">
          {NAV_LINKS.map(({ label, href, icon: Icon }) => (
            <a
              key={label}
              href={href}
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 py-2.5 text-cream/90 text-sm font-medium"
            >
              <Icon size={16} /> {label}
            </a>
          ))}
          <a
            href="#sell"
            onClick={() => setOpen(false)}
            className="mt-2 text-center text-sm font-semibold bg-gold text-forestDeep px-4 py-2.5 rounded-full"
          >
            Start Selling
          </a>
        </div>
      )}
    </header>
  );
}
