import { Clock3 } from "lucide-react";
import TrustBadge from "./TrustBadge.jsx";

const IMAGE_GRADIENTS = {
  food: "from-gold/70 to-forest/60",
  fabric: "from-flagRed/60 to-gold/60",
  electronics: "from-forest/80 to-forestDeep",
};

const formatNaira = (n) => `₦${n.toLocaleString("en-NG")}`;

export default function ProductCard({ product, seller, onOpenChat }) {
  return (
    <article className="bg-white rounded-xl2 overflow-hidden border border-forest/8 hover:shadow-lg hover:shadow-forest/10 transition-shadow flex flex-col">
      <div
        className={`h-36 bg-gradient-to-br ${IMAGE_GRADIENTS[product.image] || IMAGE_GRADIENTS.food} relative`}
      >
        {product.perishable && (
          <span className="absolute top-2.5 left-2.5 badge bg-forestDeep/85 text-cream">
            <Clock3 size={11} /> 1h dispute window
          </span>
        )}
      </div>

      <div className="p-4 flex flex-col gap-2.5 flex-1">
        <p className="text-xs font-semibold text-forest/50 uppercase tracking-wide">
          {product.category}
        </p>
        <h3 className="font-display text-base font-semibold text-forestDeep leading-snug">
          {product.title}
        </h3>
        <p className="text-lg font-bold text-forest">{formatNaira(product.price)}</p>

        {seller && (
          <div className="flex items-center justify-between pt-2 mt-auto border-t border-forest/8">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-forestDeep/80 truncate">{seller.name}</p>
              <p className="text-[11px] text-forestDeep/45">{seller.town}</p>
            </div>
            <TrustBadge tier={seller.badge} />
          </div>
        )}

        <button
          onClick={() => onOpenChat?.(product)}
          className="mt-2 w-full text-sm font-semibold bg-forest hover:bg-forestDeep text-cream py-2.5 rounded-full transition-colors"
        >
          Message Seller
        </button>
      </div>
    </article>
  );
}
